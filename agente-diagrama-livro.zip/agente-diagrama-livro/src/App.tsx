import BookFormattingAgent from './components/BookFormattingAgent';

function App() {
  return <BookFormattingAgent />;
}

export default App;
